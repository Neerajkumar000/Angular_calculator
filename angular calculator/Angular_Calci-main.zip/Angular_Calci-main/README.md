# Angular_Calci

This is a simple calculator done using AngularCLI.
